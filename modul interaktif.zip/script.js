'use strict';

/* =========================================================
   Belajar Akuntansi Dasar - logika SPA & simulasi
   Alur data: Persamaan akuntansi -> Jurnal umum -> Buku besar -> Neraca saldo
   ========================================================= */

const STORAGE_KEY = 'belajar-akuntansi-dasar-v1';

const ACCOUNTS = [
  { name: 'Kas', normal: 'D' },
  { name: 'Piutang Usaha', normal: 'D' },
  { name: 'Perlengkapan', normal: 'D' },
  { name: 'Utang Usaha', normal: 'K' },
  { name: 'Modal', normal: 'K' },
  { name: 'Pendapatan Jasa', normal: 'K' },
  { name: 'Beban Gaji', normal: 'D' },
  { name: 'Beban Listrik', normal: 'D' }
];

// Kolom tabel Persamaan akuntansi dan akun yang dituju
const EQ_COLS = [
  { key: 'kas', account: 'Kas', side: 'harta' },
  { key: 'piutang', account: 'Piutang Usaha', side: 'harta' },
  { key: 'perlengkapan', account: 'Perlengkapan', side: 'harta' },
  { key: 'utang', account: 'Utang Usaha', side: 'kewajiban' },
  { key: 'modal', account: 'Modal', side: 'modal' }
];

// State global (disimpan ke localStorage agar tidak hilang saat refresh)
let transactions = [];   // dari Persamaan akuntansi
let manualJournal = [];  // baris jurnal yang dicatat siswa sendiri
let nextId = 1;

/* ---------- Utilitas ---------- */
const $ = (id) => document.getElementById(id);

const rupiah = new Intl.NumberFormat('id-ID', { maximumFractionDigits: 2 });
const fmt = (n) => rupiah.format(n);
const round2 = (n) => Math.round(n * 100) / 100;

function esc(text) {
  const d = document.createElement('div');
  d.textContent = text;
  return d.innerHTML;
}

function todayISO() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

function formatDate(iso) {
  if (!iso) return '-';
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

function setMsg(el, text, type) {
  el.textContent = text;
  el.className = 'msg' + (type ? ' ' + type : '');
}

function accountNormal(name) {
  const acc = ACCOUNTS.find((a) => a.name === name);
  return acc ? acc.normal : 'D';
}

/* ---------- Penyimpanan ---------- */
function save() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ transactions, manualJournal, nextId }));
  } catch (e) { /* penyimpanan tidak tersedia: abaikan */ }
}

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const data = JSON.parse(raw);
    transactions = Array.isArray(data.transactions) ? data.transactions : [];
    manualJournal = Array.isArray(data.manualJournal) ? data.manualJournal : [];
    nextId = Number(data.nextId) || 1;
  } catch (e) { /* data rusak: mulai dari kosong */ }
}

/* ---------- Navigasi SPA ---------- */
const tabs = document.querySelectorAll('.tab');
const pages = document.querySelectorAll('.page');

function showTab(id, updateHash = true) {
  if (!document.getElementById(id)) id = 'beranda';
  pages.forEach((p) => {
    const active = p.id === id;
    p.hidden = !active;
    p.classList.toggle('active', active);
  });
  tabs.forEach((t) => {
    const active = t.dataset.tab === id;
    t.classList.toggle('active', active);
    t.setAttribute('aria-selected', String(active));
  });
  if (updateHash) history.replaceState(null, '', '#' + id);
  window.scrollTo({ top: 0 });
}

tabs.forEach((t) => t.addEventListener('click', () => showTab(t.dataset.tab)));
document.querySelectorAll('[data-goto]').forEach((c) =>
  c.addEventListener('click', () => showTab(c.dataset.goto))
);

/* ---------- Turunan data: jurnal, buku besar, neraca saldo ---------- */

// Setiap transaksi Persamaan akuntansi diubah menjadi baris jurnal otomatis.
// Harta bertambah = debit, harta berkurang = kredit.
// Utang/Modal bertambah = kredit, berkurang = debit.
function autoJournalLines() {
  const lines = [];
  transactions.forEach((t, i) => {
    EQ_COLS.forEach((col) => {
      const v = Number(t[col.key]) || 0;
      if (v === 0) return;
      const increase = v > 0;
      const abs = Math.abs(v);
      const isDebit = col.side === 'harta' ? increase : !increase;
      lines.push({
        date: t.date,
        account: col.account,
        ref: 'PA-' + (i + 1),
        debit: isDebit ? abs : 0,
        credit: isDebit ? 0 : abs,
        desc: t.desc,
        auto: true,
        sourceId: t.id,
        order: t.id
      });
    });
  });
  return lines;
}

function allJournalLines() {
  const manual = manualJournal.map((j) => ({
    date: j.date,
    account: j.account,
    ref: j.ref,
    debit: j.debit,
    credit: j.credit,
    desc: '',
    auto: false,
    sourceId: j.id,
    order: j.id
  }));
  const lines = autoJournalLines().concat(manual);
  // urut berdasarkan tanggal, lalu urutan input
  lines.sort((a, b) => (a.date === b.date ? a.order - b.order : a.date < b.date ? -1 : 1));
  return lines;
}

function buildLedger(lines) {
  const ledger = {};
  lines.forEach((l) => {
    if (!ledger[l.account]) ledger[l.account] = [];
    ledger[l.account].push(l);
  });
  return ledger;
}

function sumLines(lines) {
  return {
    debit: round2(lines.reduce((s, l) => s + l.debit, 0)),
    credit: round2(lines.reduce((s, l) => s + l.credit, 0))
  };
}

function balanceNote(el, debit, credit, label) {
  if (debit === 0 && credit === 0) {
    el.innerHTML = '';
    return;
  }
  const diff = round2(Math.abs(debit - credit));
  if (diff === 0) {
    el.innerHTML = `<strong class="ok">Seimbang.</strong> Total debit dan kredit sama: Rp${fmt(debit)}.`;
  } else {
    el.innerHTML = `<strong class="bad">Belum seimbang.</strong> ${label} selisih Rp${fmt(diff)} (debit Rp${fmt(debit)}, kredit Rp${fmt(credit)}).`;
  }
}

/* ---------- Render: Persamaan akuntansi ---------- */
function renderEquation() {
  const body = $('eq-body');
  if (transactions.length === 0) {
    body.innerHTML = '<tr class="empty-row"><td colspan="8">Belum ada transaksi. Isi baris di atas, lalu tekan Tambah Transaksi.</td></tr>';
  } else {
    body.innerHTML = transactions.map((t) => {
      const cells = EQ_COLS.map((c) => {
        const v = Number(t[c.key]) || 0;
        return `<td class="num ${v < 0 ? 'neg' : ''}">${v === 0 ? '-' : fmt(v)}</td>`;
      }).join('');
      return `<tr>
        <td>${formatDate(t.date)}</td>
        <td>${esc(t.desc)}</td>
        ${cells}
        <td><button class="btn-del" data-del-tx="${t.id}" aria-label="Hapus transaksi ${esc(t.desc)}">Hapus</button></td>
      </tr>`;
    }).join('');
  }

  const totals = {};
  EQ_COLS.forEach((c) => {
    totals[c.key] = round2(transactions.reduce((s, t) => s + (Number(t[c.key]) || 0), 0));
  });
  $('eq-foot').innerHTML = `<tr>
    <td colspan="2">Total</td>
    ${EQ_COLS.map((c) => `<td class="num ${totals[c.key] < 0 ? 'neg' : ''}">${fmt(totals[c.key])}</td>`).join('')}
    <td></td>
  </tr>`;

  const harta = round2(totals.kas + totals.piutang + totals.perlengkapan);
  const sisiKanan = round2(totals.utang + totals.modal);
  const note = $('eq-balance');
  if (transactions.length === 0) {
    note.innerHTML = '';
  } else if (harta === sisiKanan) {
    note.innerHTML = `<strong class="ok">Seimbang.</strong> Harta Rp${fmt(harta)} = Utang Rp${fmt(totals.utang)} + Modal Rp${fmt(totals.modal)}.`;
  } else {
    note.innerHTML = `<strong class="bad">Tidak seimbang.</strong> Harta Rp${fmt(harta)} berbeda dari Utang + Modal Rp${fmt(sisiKanan)}.`;
  }
}

/* ---------- Render: Jurnal umum ---------- */
function renderJournal() {
  const lines = allJournalLines();
  const body = $('jr-body');

  if (lines.length === 0) {
    body.innerHTML = '<tr class="empty-row"><td colspan="6">Belum ada jurnal. Tambahkan transaksi di Persamaan akuntansi atau catat jurnal di baris atas.</td></tr>';
  } else {
    body.innerHTML = lines.map((l) => {
      const indent = l.credit > 0 ? ' style="padding-left:2rem"' : '';
      const tag = l.auto ? `<span class="auto-tag" title="${esc(l.desc)}">Otomatis</span>` : '';
      const action = l.auto
        ? ''
        : `<button class="btn-del" data-del-jr="${l.sourceId}" aria-label="Hapus baris jurnal ${esc(l.account)}">Hapus</button>`;
      return `<tr>
        <td>${formatDate(l.date)}</td>
        <td${indent}>${esc(l.account)}${tag}</td>
        <td>${esc(l.ref || '-')}</td>
        <td class="num">${l.debit ? fmt(l.debit) : ''}</td>
        <td class="num">${l.credit ? fmt(l.credit) : ''}</td>
        <td>${action}</td>
      </tr>`;
    }).join('');
  }

  const s = sumLines(lines);
  $('jr-foot').innerHTML = `<tr>
    <td colspan="3">Total</td>
    <td class="num">${fmt(s.debit)}</td>
    <td class="num">${fmt(s.credit)}</td>
    <td></td>
  </tr>`;
  balanceNote($('jr-balance'), s.debit, s.credit, 'Jurnal masih');
}

/* ---------- Render: Buku besar ---------- */
function renderLedger() {
  const ledger = buildLedger(allJournalLines());
  const names = ACCOUNTS.map((a) => a.name).filter((n) => ledger[n]);
  const wrap = $('ledger');

  if (names.length === 0) {
    wrap.innerHTML = '<div class="empty-state">Buku besar masih kosong. Catat transaksi atau jurnal dulu.</div>';
    return;
  }

  wrap.innerHTML = names.map((name) => {
    const normal = accountNormal(name);
    let saldo = 0;
    const rows = ledger[name].map((l) => {
      saldo = round2(saldo + (normal === 'D' ? l.debit - l.credit : l.credit - l.debit));
      return `<tr>
        <td>${formatDate(l.date)}</td>
        <td>${esc(l.desc || l.ref || '-')}</td>
        <td class="num">${l.debit ? fmt(l.debit) : ''}</td>
        <td class="num">${l.credit ? fmt(l.credit) : ''}</td>
        <td class="num ${saldo < 0 ? 'neg' : ''}">${fmt(saldo)}</td>
      </tr>`;
    }).join('');

    return `<article class="ledger-card">
      <header><h3>${esc(name)}</h3><span>Saldo normal: ${normal === 'D' ? 'debit' : 'kredit'}</span></header>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Tanggal</th><th>Keterangan</th><th class="num">Debit</th><th class="num">Kredit</th><th class="num">Saldo</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </article>`;
  }).join('');
}

/* ---------- Render: Neraca saldo ---------- */
function renderTrialBalance() {
  const ledger = buildLedger(allJournalLines());
  const names = ACCOUNTS.map((a) => a.name).filter((n) => ledger[n]);
  const body = $('tb-body');

  if (names.length === 0) {
    body.innerHTML = '<tr class="empty-row"><td colspan="3">Belum ada data. Catat transaksi atau jurnal dulu.</td></tr>';
    $('tb-foot').innerHTML = '';
    $('tb-balance').innerHTML = '';
    return;
  }

  let totalD = 0;
  let totalK = 0;
  body.innerHTML = names.map((name) => {
    const s = sumLines(ledger[name]);
    const net = round2(s.debit - s.credit);
    const d = net > 0 ? net : 0;
    const k = net < 0 ? -net : 0;
    totalD += d;
    totalK += k;
    return `<tr>
      <td>${esc(name)}</td>
      <td class="num">${d ? fmt(d) : ''}</td>
      <td class="num">${k ? fmt(k) : ''}</td>
    </tr>`;
  }).join('');

  totalD = round2(totalD);
  totalK = round2(totalK);
  $('tb-foot').innerHTML = `<tr><td>Total</td><td class="num">${fmt(totalD)}</td><td class="num">${fmt(totalK)}</td></tr>`;
  balanceNote($('tb-balance'), totalD, totalK, 'Neraca saldo masih');
}

function renderAll() {
  renderEquation();
  renderJournal();
  renderLedger();
  renderTrialBalance();
}

/* ---------- Aksi: Persamaan akuntansi ---------- */
function addTransaction() {
  const msg = $('eq-msg');
  const desc = $('eq-desc').value.trim();
  const date = $('eq-date').value || todayISO();
  const values = {};
  EQ_COLS.forEach((c) => {
    values[c.key] = Number($('eq-' + c.key).value) || 0;
  });

  if (!desc) {
    setMsg(msg, 'Isi keterangan transaksi dulu.', 'error');
    $('eq-desc').focus();
    return;
  }

  const total = Object.values(values).reduce((s, v) => s + Math.abs(v), 0);
  if (total === 0) {
    setMsg(msg, 'Isi minimal satu angka perubahan akun.', 'error');
    return;
  }

  const harta = round2(values.kas + values.piutang + values.perlengkapan);
  const kanan = round2(values.utang + values.modal);
  if (harta !== kanan) {
    setMsg(
      msg,
      `Belum seimbang: perubahan Harta Rp${fmt(harta)}, perubahan Utang + Modal Rp${fmt(kanan)}. Periksa lagi angkanya.`,
      'error'
    );
    return;
  }

  transactions.push(Object.assign({ id: nextId++, date, desc }, values));
  save();
  renderAll();

  $('eq-desc').value = '';
  EQ_COLS.forEach((c) => { $('eq-' + c.key).value = ''; });
  $('eq-desc').focus();
  setMsg(msg, 'Transaksi ditambahkan. Cek tab Jurnal umum untuk melihat jurnalnya.', 'ok');
}

/* ---------- Aksi: Jurnal umum ---------- */
function addJournal() {
  const msg = $('jr-msg');
  const date = $('jr-date').value || todayISO();
  const account = $('jr-account').value;
  const ref = $('jr-ref').value.trim();
  const debit = round2(Number($('jr-debit').value) || 0);
  const credit = round2(Number($('jr-kredit').value) || 0);

  if (debit < 0 || credit < 0) {
    setMsg(msg, 'Debit dan kredit tidak boleh negatif.', 'error');
    return;
  }
  if (debit === 0 && credit === 0) {
    setMsg(msg, 'Isi angka di kolom debit atau kredit.', 'error');
    return;
  }
  if (debit > 0 && credit > 0) {
    setMsg(msg, 'Satu baris jurnal diisi di debit saja atau kredit saja.', 'error');
    return;
  }

  manualJournal.push({ id: nextId++, date, account, ref, debit, credit });
  save();
  renderAll();

  $('jr-debit').value = '';
  $('jr-kredit').value = '';
  $('jr-debit').focus();
  setMsg(msg, 'Baris jurnal dicatat. Pastikan total debit dan kredit sama.', 'ok');
}

/* ---------- Hapus data ---------- */
document.addEventListener('click', (e) => {
  const tx = e.target.closest('[data-del-tx]');
  if (tx) {
    const id = Number(tx.dataset.delTx);
    transactions = transactions.filter((t) => t.id !== id);
    save();
    renderAll();
    return;
  }
  const jr = e.target.closest('[data-del-jr]');
  if (jr) {
    const id = Number(jr.dataset.delJr);
    manualJournal = manualJournal.filter((j) => j.id !== id);
    save();
    renderAll();
  }
});

$('reset-all').addEventListener('click', () => {
  if (!confirm('Hapus semua data latihan di browser ini?')) return;
  transactions = [];
  manualJournal = [];
  nextId = 1;
  save();
  renderAll();
  setMsg($('eq-msg'), '', '');
  setMsg($('jr-msg'), '', '');
});

/* ---------- Kuis ---------- */
const QUIZ = [
  { q: 'q1', answer: 'b', explain: 'Persamaan dasarnya Harta = Utang + Modal.' },
  { q: 'q2', answer: 'c', explain: 'Kas bertambah (debit) dan Modal bertambah (kredit).' },
  { q: 'q3', answer: 'b', explain: 'Utang adalah kewajiban, saldo normalnya di kredit.' },
  { q: 'q4', answer: 'b', explain: 'Buku besar berisi akun-akun hasil posting dari jurnal.' },
  { q: 'q5', answer: 'd', explain: 'Neraca saldo memeriksa total debit sama dengan total kredit.' }
];

function checkQuiz(e) {
  e.preventDefault();
  const form = $('quiz-form');
  const msg = $('quiz-msg');
  let score = 0;
  let missing = 0;
  const review = [];

  QUIZ.forEach((item, i) => {
    const fieldset = form.querySelector(`input[name="${item.q}"]`).closest('fieldset');
    const chosen = form.querySelector(`input[name="${item.q}"]:checked`);
    fieldset.classList.toggle('unanswered', !chosen);
    if (!chosen) {
      missing++;
      return;
    }
    const correct = chosen.value === item.answer;
    if (correct) score++;
    review.push({ n: i + 1, correct, explain: item.explain });
  });

  if (missing > 0) {
    setMsg(msg, `Masih ada ${missing} soal yang belum dijawab.`, 'error');
    return;
  }
  setMsg(msg, '', '');

  const value = Math.round((score / QUIZ.length) * 100);
  $('result-score').textContent = value;
  $('result-text').textContent =
    `Kamu menjawab benar ${score} dari ${QUIZ.length} soal.` +
    (score === QUIZ.length ? ' Sempurna!' : score >= 3 ? ' Bagus, pelajari lagi soal yang masih salah.' : ' Coba baca lagi materinya, lalu ulangi kuisnya.');
  $('result-review').innerHTML = review.map((r) =>
    `<li class="${r.correct ? 'ok' : 'bad'}">Soal ${r.n}: ${r.correct ? 'benar' : 'salah'}. ${esc(r.explain)}</li>`
  ).join('');

  const dlg = $('result-dialog');
  if (typeof dlg.showModal === 'function') dlg.showModal();
  else alert(`Nilai kamu: ${value}`);
}

$('quiz-form').addEventListener('submit', checkQuiz);
$('quiz-form').addEventListener('change', (e) => {
  const fs = e.target.closest('fieldset');
  if (fs) fs.classList.remove('unanswered');
});
$('result-close').addEventListener('click', () => $('result-dialog').close());

/* ---------- Inisialisasi ---------- */
function init() {
  // dropdown akun jurnal
  $('jr-account').innerHTML = ACCOUNTS.map((a) => `<option value="${esc(a.name)}">${esc(a.name)}</option>`).join('');

  // tanggal bawaan hari ini
  $('eq-date').value = todayISO();
  $('jr-date').value = todayISO();

  load();
  renderAll();

  $('eq-add').addEventListener('click', addTransaction);
  $('jr-add').addEventListener('click', addJournal);

  // Enter di baris input = tombol tambah
  $('eq-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') addTransaction(); });
  $('jr-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') addJournal(); });

  showTab(location.hash.replace('#', '') || 'beranda', false);
}

init();
